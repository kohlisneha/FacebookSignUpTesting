package FacebookSignUp;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class FacebookSignupTest {
    public static void main(String[] args) {

       
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        try {
         
            driver.get("https://www.facebook.com/r.php");
            driver.manage().window().maximize();

            driver.findElement(By.name("firstname")).sendKeys("Sneha");
            driver.findElement(By.name("lastname")).sendKeys("Kohli");
            driver.findElement(By.name("reg_email__")).sendKeys("test12345@gmail.com");

            Thread.sleep(5000); 
            driver.findElement(By.name("reg_email_confirmation__")).sendKeys("test12345@gmail.com");

            driver.findElement(By.name("reg_passwd__")).sendKeys("Test@12345");

           
            driver.findElement(By.id("day")).sendKeys("15");
            driver.findElement(By.id("month")).sendKeys("Aug");
            driver.findElement(By.id("year")).sendKeys("1998");

            WebElement gender = driver.findElement(By.xpath("//input[@value='1']"));
            gender.click();

            System.out.println("✅ Facebook signup form filled successfully!");

            Thread.sleep(6000); 

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            driver.quit();
        }
    }
}
